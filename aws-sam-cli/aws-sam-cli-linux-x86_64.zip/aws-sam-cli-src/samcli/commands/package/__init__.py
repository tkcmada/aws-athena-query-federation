"""
`sam package` command
"""

# Expose the cli object here
from .command import cli  # noqa
